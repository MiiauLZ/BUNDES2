# Verificacion de mejoras conservadoras

Ejecutar desde BUNDES2:

```powershell
node --test tests/regression.cjs
node --check assets/app.js
```

Resultado verificado: 15 pruebas aprobadas y sintaxis JavaScript valida.

Cobertura: recuperacion de busqueda tras fallos totales y parciales; cuatro solicitudes de tablas en una busqueda sin cache (antes hasta doce para tablas, partidos y goleadores); reutilizacion del indice; conteo completo de partidos; dialogo unico, foco inicial, retorno de foco y Tab/Shift+Tab; estados de error; conservacion de filtros al actualizar; cancelacion; agrupacion del render al escribir; atributos accesibles de tabla; cupos de clasificacion; respuestas tardias entre ligas y al volver al inicio; preferencia de movimiento reducido.

Las pruebas usan Node y un DOM simulado. No certifican comportamiento real de navegador, lectores de pantalla, gestos tactiles, contraste, rendimiento medido ni conexion con las hojas oficiales.

Pendiente: revisar vistas a 360, 390, 768 y 1280 px, temas claro y oscuro, teclado virtual y scroll tactil en dispositivo. El navegador de la sesion bloqueo la apertura del archivo local. No se realizaron capturas ni comparacion visual.

Los cambios de implementacion estan en assets/app.js y atributos de accesibilidad de index.html. No se editaron las hojas CSS, logos ni fuentes. No se desplego el sitio.
